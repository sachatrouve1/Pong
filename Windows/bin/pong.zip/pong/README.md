Commands:

General:
	ECHAP	exit game
	SPACE	pause / unpause
	F1		mute / unmute sound
	F2		new game
	F3		fancy mode (bar skins)

Player1 (left bar):
	A		up
	Q		down

Player2 (right bar):
	P		up
	M		down


g++ main.cpp -o ../bin/pong.exe -Iinclude -Llib -lsfml-graphics-s -lsfml-window-s -lsfml-system-s -lopengl32 -lfreetype -lwinmm -lgdi32 -lopenal32 -lflac -lvorbisenc -lvorbisfile -lvorbis -logg -static-libgcc -static-libstdc++


g++ main.cpp -o ../bin/pong.exe -Iinclude -Llib -lsfml-graphics -lsfml-window -lsfml-system -lwinmm -lgdi32 -static-libgcc -static-libstdc++

g++ -o ../bin/pong.exe -IC:/SFML/include -LC:/SFML/lib -lsfml-graphics-s -lsfml-window-s -lsfml-system-s -lopengl32 -lfreetype -lwinmm -lgdi32 -lopenal32 -lflac -lvorbisenc -lvorbisfile -lvorbis -logg -static-libgcc -static-libstdc++ main.cpp

g++ -o ../bin/pong.exe -IC:\SFML\include -LC:\SFML\lib -lsfml-audio -lsfml-graphics -lsfml-window -lsfml-system